<?php
define('APIKEY', 'AIzaSyCuhvp61_DcIeeIpQWSnvyyosOg6YZ1Zu8');
define('GJ_CODE', 'US');
define('SITE_NAME', 'redrain1314');
define('TITLENAME', 'redrain1314');
define('EN2DEKEY', 'a5545b6a5056398');
define('EMAIL', 'sexyhome222@gmail.com');
define('NAME', 'gyy222');
define('PASSWORD', 'a5545b6ayxf@gmail.com');
define('LOGINHTML', '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="Login.css"/>
</head>
<body>
<center>
    <p id="login">
    <h1>µÇÂ½</h1>
    <form method="post" style="margin:0px auto;">
        <input type="text" required="required" placeholder="ÓÃ»§Ãû" name="name"></input>
        <br>
        <input type="password" required="required" placeholder="ÃÜÂë" name="password"></input>
        <button class="but" type="submit">µÇÂ¼</button>
    </form>
    </p>
</center>
</body>
</html>');
?>
